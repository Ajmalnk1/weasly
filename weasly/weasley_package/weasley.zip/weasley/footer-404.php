<?php $weasley_redux_demo = get_option('redux_demo');?> 
</body>

</html>
<?php wp_footer(); ?>